import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from root_helper import preview
from modules.display import outputs

CONFIG='''Section "Device"
    Identifier "Tegra GPU"
    Driver "nvidia"
    Option "AllowEmptyInitialConfiguration" "true"
    Option "ConnectedMonitor" "DFP"
EndSection
'''


class SafetyTests(unittest.TestCase):
    def test_preserves_everything_except_override(self):
        result=preview(CONFIG)
        self.assertIn('Option "AllowEmptyInitialConfiguration" "true"',result)
        self.assertEqual([s for s in result.splitlines() if not s.startswith('#')],
                         [s for s in CONFIG.splitlines() if 'ConnectedMonitor' not in s])

    def test_refuses_already_changed(self):
        with self.assertRaises(ValueError):preview(preview(CONFIG))

    def test_refuses_complex_or_foreign_config(self):
        for text in [CONFIG+CONFIG,CONFIG.replace('"nvidia"','"dummy"'),
                     CONFIG.replace('EndSection','Option "CustomEDID" "DFP-0:/tmp/edid"\nEndSection')]:
            with self.assertRaises(ValueError):preview(text)

    def test_disconnected_output_modes_are_not_offered(self):
        data='DP-0 connected primary 1600x900+0+0\n   1600x900 59.82*\n   1280x720 60.00\nDP-1 disconnected\n   640x480 60.00\n'
        self.assertEqual(outputs(data),{'DP-0':['1600x900','1280x720']})


if __name__=='__main__':unittest.main()
