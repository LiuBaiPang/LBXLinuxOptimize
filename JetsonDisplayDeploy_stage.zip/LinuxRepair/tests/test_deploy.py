import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from deploy import compatibility


class FleetTests(unittest.TestCase):
    def test_supported_platform(self):
        compatibility('NVIDIA Orin NX Developer Kit','# R35 (release), REVISION: 6.4, GCID: 1','aarch64')

    def test_refuses_different_platform(self):
        for model,release,arch in [
            ('NVIDIA Orin Nano','# R35 (release), REVISION: 6.4,','aarch64'),
            ('NVIDIA Orin NX','# R36 (release), REVISION: 4.4,','aarch64'),
            ('NVIDIA Orin NX','# R35 (release), REVISION: 6.4,','x86_64')]:
            with self.assertRaises(ValueError):compatibility(model,release,arch)


if __name__=='__main__':unittest.main()
